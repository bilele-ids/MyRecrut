const APP_URL = "https://my-recrut-aarb.vercel.app";

let currentTab = null;

function getSource(url) {
  if (url.includes("linkedin.com")) return "LinkedIn";
  if (url.includes("indeed.")) return "Indeed";
  if (url.includes("welcometothejungle.com")) return "Welcome to the Jungle";
  if (url.includes("hellowork.com")) return "Autre";
  return "Autre";
}

function cleanTitle(title, url) {
  // Nettoyages spécifiques par site
  if (url.includes("linkedin.com")) {
    // "Chef de projet - Google | LinkedIn" → "Chef de projet - Google"
    return title.replace(/\s*[\|｜]\s*LinkedIn.*$/i, "").split(" - ")[0].trim();
  }
  if (url.includes("welcometothejungle.com")) {
    // "Chef de projet chez Google | Welcome to the Jungle" → "Chef de projet"
    return title.replace(/\s*(chez|at)\s.*$/i, "")
                .replace(/\s*[\|｜].*$/i, "").trim();
  }
  if (url.includes("indeed.")) {
    return title.replace(/\s*[\|｜-].*Indeed.*$/i, "").trim();
  }
  // Fallback générique
  return title.split("|")[0].split(" - ")[0].split("•")[0].trim();
}

// Charger les infos de l'onglet actif
chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
  currentTab = tabs[0];
  const url = currentTab.url || "";
  const title = cleanTitle(currentTab.title || "", url);
  const source = getSource(url);

  document.getElementById("source-badge").textContent = source;
  document.getElementById("titre").textContent = title || "Non détecté";
  document.getElementById("url").textContent = url.length > 45 ? url.substring(0, 45) + "…" : url;
});

document.getElementById("btn").addEventListener("click", addToMyRecrut);

function addToMyRecrut() {
  if (!currentTab) return;

  const url = currentTab.url || "";
  const title = cleanTitle(currentTab.title || "", url);
  const source = getSource(url);

  const dest = APP_URL + "/candidatures" +
    "?poste=" + encodeURIComponent(title) +
    "&source=" + encodeURIComponent(source) +
    "&lien=" + encodeURIComponent(url);

  chrome.tabs.create({ url: dest, active: true });

  const btn = document.getElementById("btn");
  btn.textContent = "✓ Ouvert !";
  btn.disabled = true;
  setTimeout(() => window.close(), 800);
}
