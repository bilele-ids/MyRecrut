const APP_URL = "https://my-recrut-aarb.vercel.app";

let currentTab = null;

function getSource(url) {
  if (url.includes("linkedin.com")) return "LinkedIn";
  if (url.includes("indeed.")) return "Indeed";
  if (url.includes("welcometothejungle.com")) return "Welcome to the Jungle";
  if (url.includes("hellowork.com")) return "Autre";
  return "Autre";
}

function cleanTitle(title) {
  return title
    .split(" | ")[0]
    .split(" - ")[0]
    .split(" • ")[0]
    .split("(")[0]
    .trim();
}

// Charger les infos de l'onglet actif
chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
  currentTab = tabs[0];
  const url = currentTab.url || "";
  const title = cleanTitle(currentTab.title || "");
  const source = getSource(url);

  document.getElementById("source-badge").textContent = source;
  document.getElementById("titre").textContent = title || "—";
  document.getElementById("url").textContent = url.length > 45 ? url.substring(0, 45) + "…" : url;
});

document.getElementById("btn").addEventListener("click", addToMyRecrut);

function addToMyRecrut() {
  if (!currentTab) return;

  const title = cleanTitle(currentTab.title || "");
  const url = currentTab.url || "";
  const source = getSource(url);

  const dest = APP_URL + "/candidatures" +
    "?poste=" + encodeURIComponent(title) +
    "&source=" + encodeURIComponent(source) +
    "&lien=" + encodeURIComponent(url);

  chrome.tabs.create({ url: dest, active: true });

  const btn = document.getElementById("btn");
  btn.textContent = "✓ Ouvert !";
  btn.disabled = true;
  setTimeout(() => window.close(), 800);
}
