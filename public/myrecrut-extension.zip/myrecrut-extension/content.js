// MyRecrut Extension - Content Script
(function () {
  if (document.getElementById("myrecrut-btn")) return;

  const APP_URL = "https://my-recrut-aarb.vercel.app";

  function getSource() {
    const h = location.hostname;
    if (h.includes("linkedin")) return "LinkedIn";
    if (h.includes("indeed")) return "Indeed";
    if (h.includes("welcometothejungle")) return "Welcome to the Jungle";
    return "Autre";
  }

  function extractData() {
    let titre = document.title.split("|")[0].split(" - ")[0].split("•")[0].trim();
    let entreprise = "";
    let localisation = "";
    const h = location.hostname;

    if (h.includes("linkedin")) {
      const entSelectors = [
        ".job-details-jobs-unified-top-card__company-name a",
        ".jobs-unified-top-card__company-name a",
        ".topcard__org-name-link",
      ];
      for (const sel of entSelectors) {
        const el = document.querySelector(sel);
        if (el?.innerText?.trim()) { entreprise = el.innerText.trim().split("\n")[0]; break; }
      }
      const locEl = document.querySelector(".job-details-jobs-unified-top-card__bullet") ||
                    document.querySelector(".jobs-unified-top-card__bullet");
      if (locEl) localisation = locEl.innerText.trim().split("\n")[0];
    }

    if (h.includes("indeed")) {
      entreprise = (document.querySelector("[data-company-name='true']") ||
                   document.querySelector("[class*='companyName']"))?.innerText?.trim() || "";
      localisation = document.querySelector("[data-testid='job-location']")?.innerText?.trim() || "";
    }

    if (h.includes("welcometothejungle")) {
      entreprise = document.querySelector("[data-testid='company-title']")?.innerText?.trim() || "";
    }

    return { titre, entreprise, localisation };
  }

  function openMyRecrut() {
    const data = extractData();
    const source = getSource();

    const url = APP_URL + "/candidatures" +
      "?entreprise=" + encodeURIComponent(data.entreprise) +
      "&poste=" + encodeURIComponent(data.titre) +
      "&source=" + encodeURIComponent(source) +
      "&lien=" + encodeURIComponent(location.href) +
      "&localisation=" + encodeURIComponent(data.localisation);

    // Essai 1 : via le service worker (meilleur)
    try {
      chrome.runtime.sendMessage({ type: "OPEN_TAB", url: url }, function(response) {
        if (chrome.runtime.lastError || !response) {
          // Essai 2 : ouvrir un lien temporaire
          const a = document.createElement("a");
          a.href = url;
          a.target = "_blank";
          a.rel = "noopener";
          a.style.display = "none";
          document.documentElement.appendChild(a);
          a.dispatchEvent(new MouseEvent("click", { bubbles: false, cancelable: true, view: window }));
          setTimeout(() => a.remove(), 100);
        }
      });
    } catch(e) {
      // Essai 3 : navigation directe
      window.open(url, "_blank") || (location.href = url);
    }
  }

  function createButton() {
    if (document.getElementById("myrecrut-btn")) return;

    const btn = document.createElement("button");
    btn.id = "myrecrut-btn";
    btn.type = "button";
    btn.innerHTML = `
      <img src="${chrome.runtime.getURL("icons/icon128.png")}" width="18" height="18" style="border-radius:4px;flex-shrink:0"/>
      <span>Ajouter à MyRecrut</span>
    `;

    btn.addEventListener("click", function(e) {
      e.preventDefault();
      e.stopPropagation();
      openMyRecrut();

      btn.innerHTML = `<span>✓ Ouvert !</span>`;
      btn.style.background = "#22c55e";
      setTimeout(() => {
        btn.innerHTML = `
          <img src="${chrome.runtime.getURL("icons/icon128.png")}" width="18" height="18" style="border-radius:4px;flex-shrink:0"/>
          <span>Ajouter à MyRecrut</span>
        `;
        btn.style.background = "#F05A28";
      }, 2000);
    });

    document.body.appendChild(btn);
  }

  // Attendre le body
  if (document.body) {
    createButton();
  } else {
    document.addEventListener("DOMContentLoaded", createButton);
  }

  // Gérer les SPA (LinkedIn change l'URL sans recharger)
  let lastUrl = location.href;
  new MutationObserver(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      document.getElementById("myrecrut-btn")?.remove();
      setTimeout(createButton, 1500);
    }
  }).observe(document.documentElement, { childList: true, subtree: true });
})();
