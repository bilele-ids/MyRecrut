// MyRecrut Extension - Content Script
// Injecte un bouton flottant sur les pages d'offres d'emploi

(function () {
  if (document.getElementById("myrecrut-btn")) return;

  const APP_URL = "https://myrecrut.vercel.app";

  // ── Détection de la source ──────────────────────────────────
  function getSource() {
    const h = location.hostname;
    if (h.includes("linkedin")) return "LinkedIn";
    if (h.includes("indeed")) return "Indeed";
    if (h.includes("welcometothejungle")) return "Welcome to the Jungle";
    if (h.includes("hellowork")) return "Autre";
    return "Autre";
  }

  // ── Extraction des données selon le site ───────────────────
  function extractData() {
    const h = location.hostname;
    let titre = "";
    let entreprise = "";
    let localisation = "";

    if (h.includes("linkedin")) {
      // LinkedIn - multiples sélecteurs selon la version de la page
      const titreSelectors = [
        ".job-details-jobs-unified-top-card__job-title h1",
        ".jobs-unified-top-card__job-title h1",
        "h1.t-24",
        "h1",
      ];
      for (const sel of titreSelectors) {
        const el = document.querySelector(sel);
        if (el?.innerText?.trim()) { titre = el.innerText.trim().split("\n")[0]; break; }
      }

      const entSelectors = [
        ".job-details-jobs-unified-top-card__company-name a",
        ".jobs-unified-top-card__company-name a",
        ".job-details-jobs-unified-top-card__company-name",
        "[data-tracking-control-name='public_jobs_topcard-org-name']",
        ".topcard__org-name-link",
      ];
      for (const sel of entSelectors) {
        const el = document.querySelector(sel);
        if (el?.innerText?.trim()) { entreprise = el.innerText.trim().split("\n")[0]; break; }
      }

      const locSelectors = [
        ".job-details-jobs-unified-top-card__bullet",
        ".jobs-unified-top-card__bullet",
        ".topcard__flavor--bullet",
      ];
      for (const sel of locSelectors) {
        const el = document.querySelector(sel);
        if (el?.innerText?.trim()) { localisation = el.innerText.trim().split("\n")[0]; break; }
      }
    }

    else if (h.includes("indeed")) {
      titre = document.querySelector("h1[class*='jobsearch']")?.innerText?.trim()
        || document.querySelector("h1")?.innerText?.trim() || "";
      entreprise = document.querySelector("[data-company-name='true']")?.innerText?.trim()
        || document.querySelector("[class*='companyName']")?.innerText?.trim() || "";
      localisation = document.querySelector("[data-testid='job-location']")?.innerText?.trim() || "";
    }

    else if (h.includes("welcometothejungle")) {
      titre = document.querySelector("h1")?.innerText?.trim() || "";
      entreprise = document.querySelector("[data-testid='company-title']")?.innerText?.trim()
        || document.querySelector("h2")?.innerText?.trim() || "";
    }

    // Fallback : titre de l'onglet
    if (!titre) {
      titre = document.title.split("|")[0].split(" - ")[0].split("•")[0].trim();
    }

    return { titre, entreprise, localisation };
  }

  // ── Création du bouton flottant ────────────────────────────
  function createButton() {
    const btn = document.createElement("button");
    btn.id = "myrecrut-btn";
    btn.innerHTML = `
      <img src="${chrome.runtime.getURL("icons/icon128.png")}" width="18" height="18" style="border-radius:4px;"/>
      <span>Ajouter à MyRecrut</span>
    `;
    btn.title = "Ajouter cette offre à MyRecrut";

    btn.addEventListener("click", () => {
      const data = extractData();
      const source = getSource();
      const params = new URLSearchParams({
        entreprise: data.entreprise,
        poste: data.titre,
        source: source,
        lien: location.href,
        localisation: data.localisation,
      });
      window.open(`${APP_URL}/candidatures?${params.toString()}`, "_blank");

      // Feedback visuel
      btn.innerHTML = `<span>✓ Ajouté !</span>`;
      btn.style.background = "#22c55e";
      setTimeout(() => {
        btn.innerHTML = `
          <img src="${chrome.runtime.getURL("icons/icon128.png")}" width="18" height="18" style="border-radius:4px;"/>
          <span>Ajouter à MyRecrut</span>
        `;
        btn.style.background = "#F05A28";
      }, 2000);
    });

    document.body.appendChild(btn);
  }

  // ── Attendre que la page soit chargée ─────────────────────
  function init() {
    if (document.body) {
      createButton();
    } else {
      document.addEventListener("DOMContentLoaded", createButton);
    }
  }

  // Sur LinkedIn (SPA), relancer si l'URL change
  let lastUrl = location.href;
  const observer = new MutationObserver(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      const existing = document.getElementById("myrecrut-btn");
      if (existing) existing.remove();
      setTimeout(createButton, 1500);
    }
  });
  observer.observe(document.body || document.documentElement, {
    childList: true,
    subtree: true,
  });

  init();
})();
