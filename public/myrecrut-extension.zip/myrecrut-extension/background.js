// Service worker - ouvre les onglets à la demande du content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "OPEN_TAB") {
    chrome.tabs.create({ url: message.url, active: true });
    sendResponse({ ok: true });
  }
  return true;
});
